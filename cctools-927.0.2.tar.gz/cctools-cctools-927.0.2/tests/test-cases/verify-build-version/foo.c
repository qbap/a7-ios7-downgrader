#include <stdio.h>

int foo(void)
{
  printf("hello, world!\n");
  return 0;
}
